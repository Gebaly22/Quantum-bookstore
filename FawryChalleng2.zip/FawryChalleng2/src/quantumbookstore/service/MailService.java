package quantumbookstore.service;

public class MailService {

    public static void send(String email) {
        System.out.println("Sending eBook to: " + email);
    }
}
