package quantumbookstore.service;

public class ShippingService {

    public static void send(String address) {
        System.out.println("Shipping paper book to: " + address);
    }
}
